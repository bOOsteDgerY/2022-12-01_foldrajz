﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace foldrajzGUI
{
    public partial class Form1 : Form
    {
        public static int index = 0;

        public Form1()
        {
            InitializeComponent();
            foreach (var button in GetAll(this, typeof(Button)))
            {
                (button as Button).Click += LoadToForm2;
            }
        }

        public IEnumerable<Control> GetAll(Control control, Type type)
        {
            var controls = control.Controls.Cast<Control>();
            return controls.SelectMany(ctrl => GetAll(ctrl, type)).Concat(controls).Where(c => c.GetType() == type);
        }

        public void LoadToForm2(object sender, EventArgs e)
        {
            Button b = sender as Button;
            index = b.TabIndex;

            Form2 load = new Form2();
            this.Hide();
            load.ShowDialog();
            this.Close();
        }
    }
}