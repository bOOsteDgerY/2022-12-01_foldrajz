﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace foldrajzGUI
{
    public partial class Form2 : Form
    {
        public static string connString = "server=localhost;user=root;database=foldrajz;port=3306;password=";
        public MySqlConnection conn = new MySqlConnection(connString);

        public void FeladatMegold(string szoveg, string SQL)
        {
            label1.Text = szoveg;
            string sql_select = SQL;

            MySqlCommand cmd = new MySqlCommand(sql_select, conn);
            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            sda.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        #region Feladatok
        public void Feladat1()
        {
            FeladatMegold("Mi MADAGASZKÁR fővárosa?", "SELECT `fovaros` FROM `orszagok` WHERE `orszag` LIKE 'Madagaszkár';");
        }

        public void Feladat2()
        {
            FeladatMegold("Melyik ország fővárosa OUAGADOUGOU?", "SELECT `orszag` FROM `orszagok` WHERE `fovaros` LIKE 'OUAGADOUGOU';");
        }

        public void Feladat3()
        {
            FeladatMegold("Melyik ország autójele a TT?", "SELECT `orszag` FROM `orszagok` WHERE `autojel` LIKE 'TT';");
        }

        public void Feladat4()
        {
            FeladatMegold("Melyik ország pénzének jele az SGD?", "SELECT `orszag` FROM `orszagok` WHERE `penzjel` LIKE 'SGD';");
        }

        public void Feladat5()
        {
            FeladatMegold("Melyik ország nemzetközi telefon-hívószáma a 61?", "SELECT `orszag` FROM `orszagok` WHERE `telefon` = 61;");
        }

        public void Feladat6()
        {
            FeladatMegold("Mekkora területű Monaco?", "SELECT `terulet` FROM `orszagok` WHERE `orszag` LIKE 'Monaco';");
        }

        public void Feladat7()
        {
            FeladatMegold("Hányan laknak Máltán?", "SELECT `nepesseg` * 1000 AS 'népesség' FROM `orszagok` WHERE `orszag` LIKE 'Málta';");
        }

        public void Feladat8()
        {
            FeladatMegold("Mennyi Japán népsűrűsége?", "SELECT (`nepesseg` * 1000) / `terulet` AS 'népsűrűség' FROM `orszagok` WHERE `orszag` LIKE 'Japán';");
        }

        public void Feladat9()
        {
            FeladatMegold("Hány lakosa van a Földnek?", "SELECT SUM(`nepesseg`) * 1000 AS 'népesség' FROM `orszagok`;");
        }

        public void Feladat10()
        {
            FeladatMegold("Mennyi az országok területe összesen?", "SELECT SUM(`terulet`) AS 'terület' FROM `orszagok`;");
        }

        public void Feladat11()
        {
            FeladatMegold("Mennyi az országok átlagos népessége?", "SELECT AVG(`nepesseg`) * 1000 AS 'átlagos népesség' FROM `orszagok`;");
        }

        public void Feladat12()
        {
            FeladatMegold("Mennyi az országok átlagos területe?", "SELECT AVG(`terulet`) AS 'átlagos terület' FROM `orszagok`;");
        }

        public void Feladat13()
        {
            FeladatMegold("Mennyi a Föld népsűrűsége?", "SELECT (SUM(`nepesseg`) * 1000) / SUM(`terulet`) AS 'népsűrűség' FROM `orszagok`;");
        }

        public void Feladat14()
        {
            FeladatMegold("Hány 1.000.000 km2-nél nagyobb területű ország van?", "SELECT COUNT(`id`) AS 'DB' FROM `orszagok` WHERE `terulet` > 1000000;");
        }

        public void Feladat15()
        {
            FeladatMegold("Hány 100 km2-nél kisebb területű ország van?", "SELECT COUNT(`id`) AS 'DB' FROM `orszagok` WHERE `terulet` < 100;");
        }

        public void Feladat16()
        {
            FeladatMegold("Hány 20.000 főnél kevesebb lakosú ország van?", "SELECT COUNT(`id`) AS 'DB' FROM `orszagok` WHERE (`nepesseg` * 1000) < 20000;");
        }

        public void Feladat17()
        {
            FeladatMegold("Hány országra igaz, hogy területe kisebb 100 km2-nél, vagy pedig a lakossága kevesebb 20.000 főnél?",
                "SELECT COUNT(`id`) AS 'DB' FROM `orszagok` WHERE `terulet` < 100 OR (`nepesseg` * 1000) < 20000;");
        }

        public void Feladat18()
        {
            FeladatMegold("Hány ország területe 50.000 és 150.000 km2 közötti?",
                "SELECT COUNT(`id`) AS 'DB' FROM `orszagok` WHERE `terulet` BETWEEN 50000 AND 150000;");
        }

        public void Feladat19()
        {
            FeladatMegold("Hány ország lakossága 8 és 12 millió közötti?",
                "SELECT COUNT(`id`) AS 'DB' FROM `orszagok` WHERE (`nepesseg` * 1000) BETWEEN 8000000 AND 12000000;");
        }

        public void Feladat20()
        {
            FeladatMegold("Mely fővárosok népesebbek 20 millió főnél?", "SELECT `fovaros` FROM `orszagok` WHERE( `nepesseg` * 1000) > 20000000;");
        }

        public void Feladat21()
        {
            FeladatMegold("Mely országok népsűrűsége nagyobb 500 fő/km2-nél?", 
                "SELECT `orszag` FROM `orszagok` WHERE ((`nepesseg` * 1000) / `terulet`) > 500;");
        }

        public void Feladat22()
        {
            FeladatMegold("Hány ország államformája köztársaság?", "SELECT COUNT(`id`) AS 'DB' FROM `orszagok` WHERE `allamforma` LIKE 'köztársaság';");
        }

        public void Feladat23()
        {
            FeladatMegold("Mely országok pénzneme a kelet-karib dollár?", "SELECT `orszag` FROM `orszagok` WHERE `penznem` LIKE 'kelet-karib dollár';");
        }

        public void Feladat24()
        {
            FeladatMegold("Hány ország nevében van benne az 'ORSZÁG' szó?", "SELECT COUNT(`id`) AS 'DB' FROM `orszagok` WHERE `orszag` LIKE '%Ország%';");
        }

        public void Feladat25()
        {
            FeladatMegold("Mely országokban korona a hivatalos fizetőeszköz?", "SELECT `orszag` FROM `orszagok` WHERE `penznem` LIKE '%korona%';");
        }

        public void Feladat26()
        {

            FeladatMegold("Mennyi Európa területe?", "SELECT SUM(`terulet`) AS 'terület' FROM `orszagok` WHERE `foldr_hely` LIKE '%Európa%';");
        }

        public void Feladat27()
        {
            FeladatMegold("Mennyi Európa lakossága?", "SELECT SUM(`nepesseg`) * 1000 AS 'lakosság' FROM `orszagok` WHERE `foldr_hely` LIKE '%Európa%';");
        }

        public void Feladat28()
        {
            FeladatMegold("Mennyi Európa népsűrűsége?", 
                "SELECT (SUM(`nepesseg`) * 1000) / SUM(`terulet`) AS 'népsűrűség' FROM `orszagok` WHERE `foldr_hely` LIKE '%Európa%';");
        }

        public void Feladat29()
        {
            FeladatMegold("Hány ország van Afrikában?", "SELECT COUNT(`id`) AS 'DB' FROM `orszagok` WHERE `foldr_hely` LIKE '%Afrika%';");
        }

        public void Feladat30()
        {
            FeladatMegold("Mennyi Afrika lakossága?", "SELECT SUM(`nepesseg`) * 1000 AS 'lakosság' FROM `orszagok` WHERE `foldr_hely` LIKE '%Afrika%';");
        }

        public void Feladat31()
        {
            FeladatMegold("Mennyi Afrika népsűrűsége?", 
                "SELECT (SUM(`nepesseg`) * 1000) / SUM(`terulet`) AS 'népsűrűség' FROM `orszagok` WHERE `foldr_hely` LIKE '%Afrika%';");
        }

        public void Feladat32()
        {
            FeladatMegold("Melyek a szigetországok?", "SELECT `orszag` FROM `orszagok` WHERE `foldr_hely` LIKE '%szigetország%';");
        }

        public void Feladat33()
        {
            FeladatMegold("Mely országok államformája hercegség, vagy királyság?", 
                "SELECT `orszag` FROM `orszagok` WHERE `allamforma` LIKE '%hercegség%' OR `allamforma` LIKE '%királyság%';");
        }

        public void Feladat34()
        {
            FeladatMegold("Hány országnak nincs autójelzése?", "SELECT COUNT(`id`) AS 'DB' FROM `orszagok` WHERE `autojel` LIKE '';");
        }

        public void Feladat35()
        {
            FeladatMegold("Mennyi a váltószáma az aprópénznek azokban az országokban, ahol nem 100?", 
                "SELECT `valtopenz` FROM `orszagok` WHERE `valtopenz` NOT LIKE '100 %';");
        }

        public void Feladat36()
        {
            FeladatMegold("Hány ország területe kisebb Magyarországénál?",
                "SELECT COUNT(`id`) AS 'DB' FROM `orszagok` WHERE `terulet` < (SELECT `terulet` FROM `orszagok` WHERE `orszag` LIKE 'Magyarország');");
        }

        public void Feladat37()
        {
            FeladatMegold("Melyik a legnagyobb területű ország, és mennyi a területe?", 
                "SELECT `orszag`, `terulet` FROM `orszagok`ORDER BY `terulet` DESC LIMIT 1;");
        }

        public void Feladat38()
        {
            FeladatMegold("Melyik a legkisebb területű ország, és mennyi a területe?",
                "SELECT `orszag`, `terulet` FROM `orszagok` ORDER BY `terulet` ASC LIMIT 1;");
        }

        public void Feladat39()
        {
            FeladatMegold("Melyik a legnépesebb ország, és hány lakosa van?",
                "SELECT `orszag`, `nepesseg` * 1000 AS 'lakosság' FROM `orszagok` ORDER BY `nepesseg` * 1000 DESC LIMIT 1;");
        }

        public void Feladat40()
        {
            FeladatMegold("Melyik a legkisebb népességű ország, és hány lakosa van?",
                "SELECT `orszag`, `nepesseg` * 1000 AS 'lakosság' FROM `orszagok` ORDER BY `nepesseg` * 1000 ASC LIMIT 1;");
        }

        public void Feladat41()
        {
            FeladatMegold("Melyik a legsűrűbben lakott ország, és mennyi a népsűrűsége?",
                "SELECT `orszag`, (`nepesseg` * 1000) / terulet AS 'népsűrűség' FROM `orszagok` ORDER BY (`nepesseg` * 1000) / terulet DESC LIMIT 1;");
        }

        public void Feladat42()
        {
            FeladatMegold("Melyik a legritkábban lakott ország, és mennyi a népsűrűsége?",
                "SELECT `orszag`, (`nepesseg` * 1000) / terulet AS 'népsűrűség' FROM `orszagok` ORDER BY (`nepesseg` * 1000) / terulet ASC LIMIT 1;");
        }

        public void Feladat43()
        {
            FeladatMegold("Melyik a legnagyobb afrikai ország és mekkora?",
                "SELECT `orszag`, `terulet` FROM `orszagok` WHERE `foldr_hely` LIKE '%Afrika%' ORDER BY `terulet` DESC LIMIT 1;");
        }

        public void Feladat44()
        {
            FeladatMegold("Melyik a legkisebb amerikai ország és hányan lakják?",
                "SELECT `orszag`, `nepesseg` * 1000 AS 'népesség' FROM `orszagok` WHERE `foldr_hely` LIKE '%Amerika%' ORDER BY `terulet` ASC LIMIT 1;");
        }

        public void Feladat45()
        {
            FeladatMegold("Melyik az első három legsűrűbben lakott 'országméretű' ország (tehát nem város- vagy törpeállam)?",
                "SELECT `orszag` FROM `orszagok` WHERE `foldr_hely` NOT LIKE '%törpeállam%' AND `orszag` NOT LIKE `fovaros` " +
                "ORDER BY (`nepesseg` * 1000) / `terulet` DESC LIMIT 3;");
        }

        public void Feladat46()
        {
            FeladatMegold("Melyik a világ hat legnépesebb fővárosa?",
                "SELECT `fovaros` FROM `orszagok` ORDER BY `nep_fovaros` DESC LIMIT 6;");
        }

        public void Feladat47()
        {
            FeladatMegold("Melyik tíz ország egy főre jutó GDP-je a legnagyobb?",
                "SELECT `orszag` FROM `orszagok` ORDER BY (`gdp` / `nepesseg`) DESC LIMIT 10;");
        }

        public void Feladat48()
        {
            FeladatMegold("Melyik tíz ország össz-GDP-je a legnagyobb?",
                "SELECT `orszag` FROM `orszagok` ORDER BY `gdp` DESC LIMIT 10;");
        }

        public void Feladat49()
        {
            FeladatMegold("Melyik országban a legszegényebbek az emberek?",
                "SELECT `orszag` FROM `orszagok` ORDER BY (`gdp` / `nepesseg`) ASC LIMIT 1;");
        }

        public void Feladat50()
        {
            FeladatMegold("Melyik a 40. legkisebb területű ország?",
                "SELECT `orszag` FROM `orszagok` ORDER BY `terulet` ASC LIMIT 1 OFFSET 39;");
        }

        public void Feladat51()
        {
            FeladatMegold("Melyik a 15. legkisebb népsűrűségű ország?",
                "SELECT `orszag` FROM `orszagok` ORDER BY (`nepesseg` * 1000) / `terulet` ASC LIMIT 1 OFFSET 14;");
        }

        public void Feladat52()
        {
            FeladatMegold("Melyik a 61. legnagyobb népsűrűségű ország?",
                "SELECT `orszag` FROM `orszagok` ORDER BY (`nepesseg` * 1000) / `terulet` DESC LIMIT 1 OFFSET 60;");
        }

        public void Feladat53()
        {
            FeladatMegold("Melyik három ország területe hasonlít leginkább Magyaroszág méretéhez?",
                "SELECT `orszag` FROM `orszagok` WHERE `orszag` NOT LIKE 'Magyarország' GROUP BY `orszag` " +
                "ORDER BY ABS((`terulet` - (SELECT `terulet` FROM `orszagok` WHERE `orszag` LIKE 'Magyarország'))) ASC LIMIT 3;");
        }

        public void Feladat54()
        {
            FeladatMegold("Az emberek hányadrésze él Ázsiában?",
                "SELECT SUM(nepesseg) / (SELECT SUM(nepesseg) FROM orszagok) AS 'hányadrész' FROM orszagok WHERE foldr_hely LIKE '%Ázsia%';");
        }

        public void Feladat55()
        {
            FeladatMegold("A szárazföldek mekkora hányadát foglalja el Oroszország?",
                "SELECT SUM(`terulet`) / (SELECT SUM(`terulet`) FROM orszagok) AS 'hányad' FROM orszagok WHERE `orszag` LIKE 'Oroszország';");
        }

        public void Feladat56()
        {
            FeladatMegold("Az emberek hány százaléka fizet euroval?",
                "SELECT SUM(`nepesseg`) / (SELECT SUM(`nepesseg`) FROM orszagok) AS 'százalék' FROM orszagok WHERE `penzjel` LIKE 'EUR';");
        }

        public void Feladat57()
        {
            FeladatMegold("Hányszorosa a leggazdagabb ország egy főre jutó GDP-je a legszegényebb ország egy főre jutó GDP-jének?",
                "SELECT (`gdp` / `nepesseg`) / (SELECT `gdp` / `nepesseg` FROM `orszagok` WHERE `gdp` > 0 GROUP BY `orszag` " +
                "ORDER BY `gdp` / `nepesseg` ASC LIMIT 1) AS 'hányszoros' FROM `orszagok` GROUP BY `orszag` ORDER BY (`gdp` / `nepesseg`) DESC LIMIT 1; ");
        }

        public void Feladat58()
        {
            FeladatMegold("A világ össz-GDP-jének hány százalékát adja az USA?",
                "SELECT (SUM(`gdp`) / (SELECT SUM(`gdp`) FROM orszagok)) * 100 AS 'százalék' FROM orszagok WHERE orszag = 'Amerikai Egyesült Államok';");
        }

        public void Feladat59()
        {
            FeladatMegold("A világ össz-GDP-jének hány százalékát adja az euroövezet?",
                "SELECT (SUM(`gdp`) / (SELECT SUM(`gdp`) FROM `orszagok`)) * 100 AS 'százalék' FROM `orszagok` WHERE `penzjel` LIKE 'EUR';");
        }

        public void Feladat60()
        {
            FeladatMegold("Melyek azok az átlagnál gazdagabb országok, amelyek nem az európai vagy az amerikai kontinensen találhatóak?",
                "SELECT `orszag` FROM `orszagok` WHERE `gdp` > (SELECT AVG(`gdp`) FROM `orszagok`) " +
                "AND `foldr_hely` NOT LIKE '%Európa%' AND `foldr_hely` NOT LIKE '%Amerika%';");
        }

        public void Feladat61()
        {
            FeladatMegold("Milyen államformák léteznek Európában?",
                "SELECT DISTINCT `allamforma` FROM `orszagok` WHERE `foldr_hely` LIKE '%Európa%';");
        }

        public void Feladat62()
        {
            FeladatMegold("Hányféle államforma létezik a világon?",
                "SELECT COUNT(DISTINCT `allamforma`) AS 'DB' FROM `orszagok`;");
        }

        public void Feladat63()
        {
            FeladatMegold("Hányféle fizetőeszközt használnak Európában az eurón kívül?",
                "SELECT COUNT(DISTINCT penzjel) AS 'DB' FROM orszagok WHERE penzjel NOT LIKE 'EUR' AND foldr_hely LIKE '%Európa%';");
        }

        public void Feladat64()
        {
            FeladatMegold("Mely pénznemeket használják több országban is?",
                "SELECT `penznem` FROM `orszagok` GROUP BY `penznem` HAVING COUNT(`penznem`) > 1;");
        }

        public void Feladat65()
        {
            FeladatMegold("Mely országok államformája egyedi?",
                "SELECT `orszag` FROM `orszagok` GROUP BY `allamforma` HAVING COUNT(`allamforma`) = 1;");
        }
        #endregion

        #region Feladat_Kivalasztasa
        public void Eredmenyek()
        {
            if (Form1.index == 0)
                Feladat1();
            else if (Form1.index == 1)
                Feladat2();
            else if (Form1.index == 2)
                Feladat3();
            else if (Form1.index == 3)
                Feladat4();
            else if (Form1.index == 4)
                Feladat5();
            else if (Form1.index == 5)
                Feladat6();
            else if (Form1.index == 6)
                Feladat7();
            else if (Form1.index == 7)
                Feladat8();
            else if (Form1.index == 8)
                Feladat9();
            else if (Form1.index == 9)
                Feladat10();
            else if (Form1.index == 10)
                Feladat11();
            else if (Form1.index == 11)
                Feladat12();
            else if (Form1.index == 12)
                Feladat13();
            else if (Form1.index == 13)
                Feladat14();
            else if (Form1.index == 14)
                Feladat15();
            else if (Form1.index == 15)
                Feladat16();
            else if (Form1.index == 16)
                Feladat17();
            else if (Form1.index == 17)
                Feladat18();
            else if (Form1.index == 18)
                Feladat19();
            else if (Form1.index == 19)
                Feladat20();
            else if (Form1.index == 20)
                Feladat21();
            else if (Form1.index == 21)
                Feladat22();
            else if (Form1.index == 22)
                Feladat23();
            else if (Form1.index == 23)
                Feladat24();
            else if (Form1.index == 24)
                Feladat25();
            else if (Form1.index == 25)
                Feladat26();
            else if (Form1.index == 26)
                Feladat27();
            else if (Form1.index == 27)
                Feladat28();
            else if (Form1.index == 28)
                Feladat29();
            else if (Form1.index == 29)
                Feladat30();
            else if (Form1.index == 30)
                Feladat31();
            else if (Form1.index == 31)
                Feladat32();
            else if (Form1.index == 32)
                Feladat33();
            else if (Form1.index == 33)
                Feladat34();
            else if (Form1.index == 34)
                Feladat35();
            else if (Form1.index == 35)
                Feladat36();
            else if (Form1.index == 36)
                Feladat37();
            else if (Form1.index == 37)
                Feladat38();
            else if (Form1.index == 38)
                Feladat39();
            else if (Form1.index == 39)
                Feladat40();
            else if (Form1.index == 40)
                Feladat41();
            else if (Form1.index == 41)
                Feladat42();
            else if (Form1.index == 42)
                Feladat43();
            else if (Form1.index == 43)
                Feladat44();
            else if (Form1.index == 44)
                Feladat45();
            else if (Form1.index == 45)
                Feladat46();
            else if (Form1.index == 46)
                Feladat47();
            else if (Form1.index == 47)
                Feladat48();
            else if (Form1.index == 48)
                Feladat49();
            else if (Form1.index == 49)
                Feladat50();
            else if (Form1.index == 50)
                Feladat51();
            else if (Form1.index == 51)
                Feladat52();
            else if (Form1.index == 52)
                Feladat53();
            else if (Form1.index == 53)
                Feladat54();
            else if (Form1.index == 54)
                Feladat55();
            else if (Form1.index == 55)
                Feladat56();
            else if (Form1.index == 56)
                Feladat57();
            else if (Form1.index == 57)
                Feladat58();
            else if (Form1.index == 58)
                Feladat59();
            else if (Form1.index == 59)
                Feladat60();
            else if (Form1.index == 60)
                Feladat61();
            else if (Form1.index == 61)
                Feladat62();
            else if (Form1.index == 62)
                Feladat63();
            else if (Form1.index == 63)
                Feladat64();
            else 
                Feladat65();
        }
        #endregion

        public Form2()
        {
            try
            {
                conn.Open();
                InitializeComponent();
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
                Eredmenyek();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 load = new Form1();
            this.Hide();
            load.ShowDialog();
            this.Close();
        }
    }
}
