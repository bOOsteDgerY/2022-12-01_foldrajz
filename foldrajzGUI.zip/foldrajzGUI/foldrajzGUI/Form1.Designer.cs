﻿
namespace foldrajzGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.AutoEllipsis = true;
            this.button1.Location = new System.Drawing.Point(125, 94);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(29, 28);
            this.button1.TabIndex = 0;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(159, 94);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(29, 28);
            this.button2.TabIndex = 1;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(193, 94);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(29, 28);
            this.button3.TabIndex = 2;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(226, 94);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(29, 28);
            this.button4.TabIndex = 3;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(260, 94);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(29, 28);
            this.button5.TabIndex = 4;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(294, 94);
            this.button6.Margin = new System.Windows.Forms.Padding(2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(29, 28);
            this.button6.TabIndex = 5;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(328, 94);
            this.button7.Margin = new System.Windows.Forms.Padding(2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(29, 28);
            this.button7.TabIndex = 6;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(362, 94);
            this.button8.Margin = new System.Windows.Forms.Padding(2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(29, 28);
            this.button8.TabIndex = 7;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(395, 94);
            this.button9.Margin = new System.Windows.Forms.Padding(2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(29, 28);
            this.button9.TabIndex = 8;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(429, 94);
            this.button10.Margin = new System.Windows.Forms.Padding(2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(29, 28);
            this.button10.TabIndex = 9;
            this.button10.Text = "10";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(125, 127);
            this.button11.Margin = new System.Windows.Forms.Padding(2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(29, 28);
            this.button11.TabIndex = 10;
            this.button11.Text = "11";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(159, 127);
            this.button12.Margin = new System.Windows.Forms.Padding(2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(29, 28);
            this.button12.TabIndex = 11;
            this.button12.Text = "12";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(193, 127);
            this.button13.Margin = new System.Windows.Forms.Padding(2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(29, 28);
            this.button13.TabIndex = 12;
            this.button13.Text = "13";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(226, 127);
            this.button14.Margin = new System.Windows.Forms.Padding(2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(29, 28);
            this.button14.TabIndex = 13;
            this.button14.Text = "14";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(260, 127);
            this.button15.Margin = new System.Windows.Forms.Padding(2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(29, 28);
            this.button15.TabIndex = 14;
            this.button15.Text = "15";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(294, 127);
            this.button16.Margin = new System.Windows.Forms.Padding(2);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(29, 28);
            this.button16.TabIndex = 15;
            this.button16.Text = "16";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(328, 127);
            this.button17.Margin = new System.Windows.Forms.Padding(2);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(29, 28);
            this.button17.TabIndex = 16;
            this.button17.Text = "17";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(362, 127);
            this.button18.Margin = new System.Windows.Forms.Padding(2);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(29, 28);
            this.button18.TabIndex = 17;
            this.button18.Text = "18";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(395, 127);
            this.button19.Margin = new System.Windows.Forms.Padding(2);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(29, 28);
            this.button19.TabIndex = 18;
            this.button19.Text = "19";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(429, 127);
            this.button20.Margin = new System.Windows.Forms.Padding(2);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(29, 28);
            this.button20.TabIndex = 19;
            this.button20.Text = "20";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(429, 194);
            this.button21.Margin = new System.Windows.Forms.Padding(2);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(29, 28);
            this.button21.TabIndex = 39;
            this.button21.Text = "40";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(395, 194);
            this.button22.Margin = new System.Windows.Forms.Padding(2);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(29, 28);
            this.button22.TabIndex = 38;
            this.button22.Text = "39";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(362, 194);
            this.button23.Margin = new System.Windows.Forms.Padding(2);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(29, 28);
            this.button23.TabIndex = 37;
            this.button23.Text = "38";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(328, 194);
            this.button24.Margin = new System.Windows.Forms.Padding(2);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(29, 28);
            this.button24.TabIndex = 36;
            this.button24.Text = "37";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(294, 194);
            this.button25.Margin = new System.Windows.Forms.Padding(2);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(29, 28);
            this.button25.TabIndex = 35;
            this.button25.Text = "36";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(260, 194);
            this.button26.Margin = new System.Windows.Forms.Padding(2);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(29, 28);
            this.button26.TabIndex = 34;
            this.button26.Text = "35";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(226, 194);
            this.button27.Margin = new System.Windows.Forms.Padding(2);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(29, 28);
            this.button27.TabIndex = 33;
            this.button27.Text = "34";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(193, 194);
            this.button28.Margin = new System.Windows.Forms.Padding(2);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(29, 28);
            this.button28.TabIndex = 32;
            this.button28.Text = "33";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(159, 194);
            this.button29.Margin = new System.Windows.Forms.Padding(2);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(29, 28);
            this.button29.TabIndex = 31;
            this.button29.Text = "32";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(125, 194);
            this.button30.Margin = new System.Windows.Forms.Padding(2);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(29, 28);
            this.button30.TabIndex = 30;
            this.button30.Text = "31";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(429, 161);
            this.button31.Margin = new System.Windows.Forms.Padding(2);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(29, 28);
            this.button31.TabIndex = 29;
            this.button31.Text = "30";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(395, 161);
            this.button32.Margin = new System.Windows.Forms.Padding(2);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(29, 28);
            this.button32.TabIndex = 28;
            this.button32.Text = "29";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(362, 161);
            this.button33.Margin = new System.Windows.Forms.Padding(2);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(29, 28);
            this.button33.TabIndex = 27;
            this.button33.Text = "28";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(328, 161);
            this.button34.Margin = new System.Windows.Forms.Padding(2);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(29, 28);
            this.button34.TabIndex = 26;
            this.button34.Text = "27";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(294, 161);
            this.button35.Margin = new System.Windows.Forms.Padding(2);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(29, 28);
            this.button35.TabIndex = 25;
            this.button35.Text = "26";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(260, 161);
            this.button36.Margin = new System.Windows.Forms.Padding(2);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(29, 28);
            this.button36.TabIndex = 24;
            this.button36.Text = "25";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(226, 161);
            this.button37.Margin = new System.Windows.Forms.Padding(2);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(29, 28);
            this.button37.TabIndex = 23;
            this.button37.Text = "24";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(193, 161);
            this.button38.Margin = new System.Windows.Forms.Padding(2);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(29, 28);
            this.button38.TabIndex = 22;
            this.button38.Text = "23";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(159, 161);
            this.button39.Margin = new System.Windows.Forms.Padding(2);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(29, 28);
            this.button39.TabIndex = 21;
            this.button39.Text = "22";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(125, 161);
            this.button40.Margin = new System.Windows.Forms.Padding(2);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(29, 28);
            this.button40.TabIndex = 20;
            this.button40.Text = "21";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(342, 294);
            this.button56.Margin = new System.Windows.Forms.Padding(2);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(29, 28);
            this.button56.TabIndex = 64;
            this.button56.Text = "65";
            this.button56.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(308, 294);
            this.button57.Margin = new System.Windows.Forms.Padding(2);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(29, 28);
            this.button57.TabIndex = 63;
            this.button57.Text = "64";
            this.button57.UseVisualStyleBackColor = true;
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(274, 294);
            this.button58.Margin = new System.Windows.Forms.Padding(2);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(29, 28);
            this.button58.TabIndex = 62;
            this.button58.Text = "63";
            this.button58.UseVisualStyleBackColor = true;
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(241, 294);
            this.button59.Margin = new System.Windows.Forms.Padding(2);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(29, 28);
            this.button59.TabIndex = 61;
            this.button59.Text = "62";
            this.button59.UseVisualStyleBackColor = true;
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(207, 294);
            this.button60.Margin = new System.Windows.Forms.Padding(2);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(29, 28);
            this.button60.TabIndex = 60;
            this.button60.Text = "61";
            this.button60.UseVisualStyleBackColor = true;
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(429, 261);
            this.button61.Margin = new System.Windows.Forms.Padding(2);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(29, 28);
            this.button61.TabIndex = 59;
            this.button61.Text = "60";
            this.button61.UseVisualStyleBackColor = true;
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(395, 261);
            this.button62.Margin = new System.Windows.Forms.Padding(2);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(29, 28);
            this.button62.TabIndex = 58;
            this.button62.Text = "59";
            this.button62.UseVisualStyleBackColor = true;
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(362, 261);
            this.button63.Margin = new System.Windows.Forms.Padding(2);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(29, 28);
            this.button63.TabIndex = 57;
            this.button63.Text = "58";
            this.button63.UseVisualStyleBackColor = true;
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(328, 261);
            this.button64.Margin = new System.Windows.Forms.Padding(2);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(29, 28);
            this.button64.TabIndex = 56;
            this.button64.Text = "57";
            this.button64.UseVisualStyleBackColor = true;
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(294, 261);
            this.button65.Margin = new System.Windows.Forms.Padding(2);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(29, 28);
            this.button65.TabIndex = 55;
            this.button65.Text = "56";
            this.button65.UseVisualStyleBackColor = true;
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(260, 261);
            this.button66.Margin = new System.Windows.Forms.Padding(2);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(29, 28);
            this.button66.TabIndex = 54;
            this.button66.Text = "55";
            this.button66.UseVisualStyleBackColor = true;
            // 
            // button67
            // 
            this.button67.Location = new System.Drawing.Point(226, 261);
            this.button67.Margin = new System.Windows.Forms.Padding(2);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(29, 28);
            this.button67.TabIndex = 53;
            this.button67.Text = "54";
            this.button67.UseVisualStyleBackColor = true;
            // 
            // button68
            // 
            this.button68.Location = new System.Drawing.Point(193, 261);
            this.button68.Margin = new System.Windows.Forms.Padding(2);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(29, 28);
            this.button68.TabIndex = 52;
            this.button68.Text = "53";
            this.button68.UseVisualStyleBackColor = true;
            // 
            // button69
            // 
            this.button69.Location = new System.Drawing.Point(159, 261);
            this.button69.Margin = new System.Windows.Forms.Padding(2);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(29, 28);
            this.button69.TabIndex = 51;
            this.button69.Text = "52";
            this.button69.UseVisualStyleBackColor = true;
            // 
            // button70
            // 
            this.button70.Location = new System.Drawing.Point(125, 261);
            this.button70.Margin = new System.Windows.Forms.Padding(2);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(29, 28);
            this.button70.TabIndex = 50;
            this.button70.Text = "51";
            this.button70.UseVisualStyleBackColor = true;
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(429, 227);
            this.button71.Margin = new System.Windows.Forms.Padding(2);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(29, 28);
            this.button71.TabIndex = 49;
            this.button71.Text = "50";
            this.button71.UseVisualStyleBackColor = true;
            // 
            // button72
            // 
            this.button72.Location = new System.Drawing.Point(395, 227);
            this.button72.Margin = new System.Windows.Forms.Padding(2);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(29, 28);
            this.button72.TabIndex = 48;
            this.button72.Text = "49";
            this.button72.UseVisualStyleBackColor = true;
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(362, 227);
            this.button73.Margin = new System.Windows.Forms.Padding(2);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(29, 28);
            this.button73.TabIndex = 47;
            this.button73.Text = "48";
            this.button73.UseVisualStyleBackColor = true;
            // 
            // button74
            // 
            this.button74.Location = new System.Drawing.Point(328, 227);
            this.button74.Margin = new System.Windows.Forms.Padding(2);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(29, 28);
            this.button74.TabIndex = 46;
            this.button74.Text = "47";
            this.button74.UseVisualStyleBackColor = true;
            // 
            // button75
            // 
            this.button75.Location = new System.Drawing.Point(294, 227);
            this.button75.Margin = new System.Windows.Forms.Padding(2);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(29, 28);
            this.button75.TabIndex = 45;
            this.button75.Text = "46";
            this.button75.UseVisualStyleBackColor = true;
            // 
            // button76
            // 
            this.button76.Location = new System.Drawing.Point(260, 227);
            this.button76.Margin = new System.Windows.Forms.Padding(2);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(29, 28);
            this.button76.TabIndex = 44;
            this.button76.Text = "45";
            this.button76.UseVisualStyleBackColor = true;
            // 
            // button77
            // 
            this.button77.Location = new System.Drawing.Point(226, 227);
            this.button77.Margin = new System.Windows.Forms.Padding(2);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(29, 28);
            this.button77.TabIndex = 43;
            this.button77.Text = "44";
            this.button77.UseVisualStyleBackColor = true;
            // 
            // button78
            // 
            this.button78.Location = new System.Drawing.Point(193, 227);
            this.button78.Margin = new System.Windows.Forms.Padding(2);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(29, 28);
            this.button78.TabIndex = 42;
            this.button78.Text = "43";
            this.button78.UseVisualStyleBackColor = true;
            // 
            // button79
            // 
            this.button79.Location = new System.Drawing.Point(159, 227);
            this.button79.Margin = new System.Windows.Forms.Padding(2);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(29, 28);
            this.button79.TabIndex = 41;
            this.button79.Text = "42";
            this.button79.UseVisualStyleBackColor = true;
            // 
            // button80
            // 
            this.button80.Location = new System.Drawing.Point(125, 227);
            this.button80.Margin = new System.Windows.Forms.Padding(2);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(29, 28);
            this.button80.TabIndex = 40;
            this.button80.Text = "41";
            this.button80.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(591, 418);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button65);
            this.Controls.Add(this.button66);
            this.Controls.Add(this.button67);
            this.Controls.Add(this.button68);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button70);
            this.Controls.Add(this.button71);
            this.Controls.Add(this.button72);
            this.Controls.Add(this.button73);
            this.Controls.Add(this.button74);
            this.Controls.Add(this.button75);
            this.Controls.Add(this.button76);
            this.Controls.Add(this.button77);
            this.Controls.Add(this.button78);
            this.Controls.Add(this.button79);
            this.Controls.Add(this.button80);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
    }
}

